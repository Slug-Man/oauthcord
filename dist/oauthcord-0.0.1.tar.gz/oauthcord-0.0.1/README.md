# OauthCord
### A discord Oauth2 wrapper for python.